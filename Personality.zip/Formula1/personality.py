import os, sys
THRESHOLD = 50
TOTAL_QUESTIONS = 20
INVALID_INPUT = "Bad input detected. Please try again."

class Personality:
    THRESHOLD = 50
    TOTAL_QUESTIONS = 20

    def __init__(self, answer):
        self._answer = answer
        self._mbti = self.analysis()

    def getPersonality(self):
        return self._mbti
    
    def getAnswer(self):
        return self._answer
    
    def analysis(self):
        numB = [0 for _ in range(4)]
        for i in range(self.TOTAL_QUESTIONS):
            index = i % 4
            if self._answer[i].upper() == 'B':
                numB[index] += 1
        percent = [num//5* 100 for num in numB]

        choices = ["EI", "SN", "TF", "JP"]
        mbti = ""
        for i,per in enumerate(percent):
            if per >= self.THRESHOLD:
                mbti += choices[i][1]
            else:
                mbti += choices[i][0]
        return mbti


hehe = Personality("AABBAABBAABBAABBAABB")
print(hehe.getAnswer())
print(hehe.getPersonality())


    

