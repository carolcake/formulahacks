// Fetch the quiz data from the JSON file
//Personality questions
document.addEventListener('DOMContentLoaded', function() {
    fetch('./mbti_test.json')
        .then(response => response.json())
        .then(data => {
            const quizQuestionsDiv = document.getElementById('quizQuestions');
            data.forEach((questionData, index) => {
                const questionNumber = index + 1;
                const questionText = questionData.question;
                const choiceA = questionData.choiceA;
                const choiceB = questionData.choiceB;
                quizQuestionsDiv.appendChild(createQuestionElement(questionNumber, questionText, choiceA, choiceB));
            });

        });

    // Creates personality individual questions w/ buttons 
    function createQuestionElement(questionNumber, question, choiceA, choiceB) {
        const div = document.createElement('div');
        div.innerHTML = `
            <p><strong>${questionNumber}. ${question}</strong></p>
            <label>
                <input type="radio" name="q${questionNumber}" value="A" data-required>
                <span>${choiceA}</span>
            </label><br>
            <label>
                <input type="radio" name="q${questionNumber}" value="B" data-required>
                <span>${choiceB}</span>
            </label><br><br>
        `;
        // Event listener for radio button change
        div.querySelectorAll('input[type="radio"]').forEach(input => {
            input.addEventListener('change', function() {
                captureAnswer(questionNumber, this.value);
            });
        });
        return div;
    }

    // Access the nationality and year elements
    /*const nationality = document.getElementById('nation').value.toUpperCase().trim();
    const yearInput = document.getElementById('optionalQuestions').querySelector('#year').value;

    // Event listener for nationality selection
    nationality.addEventListener('change', function() {
        captureAnswer('nation', this.value.toUpperCase().trim());
    });

    // Event listener for number input
    yearInput.addEventListener('input', function() {
        captureAnswer('year', this.value);
    });*/


    //Processes quiz results once submit is clicked
    const quizForm = document.getElementById('quizForm');
    quizForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        if (validateForm()) {
            // stores personality type
            const personalityType = analyzeAnswers();
            const nationality = document.getElementById('nation').value.toUpperCase().trim();
            const year = document.getElementById('optionalQuestions').querySelector('#year').value;
            // Display the MBTI personality type in the HTML
            window.location.href = `personality_result.html?result=${personalityType}&nationality=${nationality}&year=${year}`;
            
        } else {
            alert('Please answer all 20 questions.');
        }
    });

    //checks if all questions are answered, returns True or False
    function validateForm() {
        const requiredQuestions = document.querySelectorAll('[data-required]');
        for (let i = 0; i < requiredQuestions.length; i++) {
            const name = requiredQuestions[i].getAttribute('name');
            const answer = document.querySelector(`input[name="${name}"]:checked`);
            if (!answer) {
                return false;
            }
        }
        return true;
    }


    // Object to store user's answers
    const userAnswers = {};

    // Function to capture user's personality answer
    function captureAnswer(questionNumber, choice) {
        userAnswers[questionNumber] = choice;
    }

    // Function to analyze the user's answers and determine the MBTI personality type
    function analyzeAnswers() {
        const numB = [0, 0, 0, 0];
        for (const questionNumber in userAnswers) {
            const index = (parseInt(questionNumber) - 1) % 4;
            if (userAnswers[questionNumber].toUpperCase() === 'B') {
                numB[index]++;
            }
        }
        const percent = numB.map(num => Math.floor(num / 5 * 100));

        const choices = ["EI", "SN", "TF", "JP"];
        let mbti = "";
        for (let i = 0; i < percent.length; i++) {
            if (percent[i] >= 50) {
                mbti += choices[i][1];
            } else {
                mbti += choices[i][0];
            }
        }
        return mbti;
    }
});


