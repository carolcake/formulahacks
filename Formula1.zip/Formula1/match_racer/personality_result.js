console.log(window.personalityType);
console.log(window.nationality);
console.log(window.year);
// Use personalityType for filtering CSV data
// Assume playerData is your CSV data loaded as an array of objects
async function fetchAndParseCSV() {
    const response = await fetch('F1DriversDataset.csv');
    const text = await response.text();
    const rows = text.split('\n');
    const headers = rows[0].split(',');
    const driverData = rows.slice(1).map(row => {
        const values = row.split(',');
        const obj = {};
        headers.forEach((header, index) => {
            let value = values[index].trim();
            if (header.trim() === 'Seasons') {
                // Remove the quotes and brackets, and split into an array
                value = value.replace(/[\[\]"]+/g,'').split(',').map(season => season.trim());
            }
            obj[header.trim()] = value;
        });
        return obj;
    });
    return driverData;
}

// Filter the CSV data based on personalityType
async function filterCSVData() {
    const driverData = await fetchAndParseCSV();
    let filteredDrivers = driverData;
    if (personalityType) {
        filteredDrivers = filteredDrivers.filter(driver => driver.MBTI === personalityType);
    }


    return filteredDrivers;
}

function displayFilteredDrivers(filteredDrivers, nationality, year) {
    const resultContainer = document.getElementById('resultContainer');
    resultContainer.innerHTML = ''; // Clear previous result

    // Display filtered drivers in groups of three
    for (let i = 0; i < filteredDrivers.length; i += 3) {
        const row = document.createElement('div');
        row.classList.add('driver-row');

        for (let j = i; j < i + 3 && j < filteredDrivers.length; j++) {
            const driver = filteredDrivers[j];
            const driverDiv = document.createElement('div');
            driverDiv.classList.add('driver');

            driverDiv.innerHTML = `
                <h3>${driver.Driver}</h3>
                <p><strong>Nationality:</strong> ${driver.Nationality}, <strong>MBTI:</strong> ${driver.MBTI}</p>
                <p><strong>Seasons:</strong><br>${driver.season}</p>
                <p><strong>Championships:</strong> ${driver.Championships}, <strong>Pole Positions:</strong> ${driver.Pole_Positions}</p>
            `;
            row.appendChild(driverDiv);
        }

        resultContainer.appendChild(row);
    }
}

// Example: Display filtered drivers
filterCSVData().then(filteredDrivers => {
    displayFilteredDrivers(filteredDrivers, nationality, year);
});